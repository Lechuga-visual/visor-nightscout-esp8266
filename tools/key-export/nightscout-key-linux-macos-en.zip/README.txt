NIGHTSCOUT PUBLIC KEY - ENGLISH

Windows: extract the ZIP and double-click Get-Nightscout-Key.cmd.
macOS: extract the ZIP and double-click Get-Nightscout-Key.command.
Linux: run bash get-nightscout-key.sh from its folder.

Enter only the HTTPS site URL, without a token or password.
A verified public key is saved as a new TXT on your Desktop (home folder fallback).
Copy all of it into Settings > HTTPS security > PEM on the Wemos.
No Python cryptography install is needed. Windows uses built-in PowerShell;
macOS uses system tools. Linux needs OpenSSL and optionally Zenity/KDialog/Tk.
Untrusted, expired or wrong-host certificates are rejected. No files are overwritten.

https://github.com/Lechuga-visual/visor-nightscout-esp8266/blob/main/tools/key-export/README.en.md
